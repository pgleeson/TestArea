#include <stdio.h>
#include "hocdec.h"
/* change name when structures in neuron.exe change*/
/* and also change the mos2nrn1.sh script */
int nocmodl5_5;

modl_reg(){
	nrn_mswindll_stdio(stdin, stdout, stderr);
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," FastSynInput.mod");
fprintf(stderr," KDR.mod");
fprintf(stderr," LTSInterToNTPyram.mod");
fprintf(stderr," LeakConductance.mod");
fprintf(stderr," NaF.mod");
NOT_PARALLEL_SUB(fprintf(stderr, "\n");)
_FastSynInput_reg();
_KDR_reg();
_LTSInterToNTPyram_reg();
_LeakConductance_reg();
_NaF_reg();
}
